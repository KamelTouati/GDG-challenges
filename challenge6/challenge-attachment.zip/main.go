package main

import (
	"fmt"
	"log"
	"net/http"
)

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/panic", panicDemo) // a route that panics
	mux.HandleFunc("/", hello)          // a route that does not panic
	log.Fatal(http.ListenAndServe(":3000", mux))
}

func panicDemo(w http.ResponseWriter, r *http.Request) {
	// if the server executes this route, it will crash, we need to recover form this as described in the challenge
	panic("Oh No No No No No! Booom")
}

func hello(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "<h1>Hoowch, I didn't panic!</h1>")
}
