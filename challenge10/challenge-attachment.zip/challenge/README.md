# Palestine Challenge

## Challenge Overview
Welcome to palestine challenge . in this challenge you must create a palesting flag using 3d library like three.js or babylon.js or any other library you want .


## Challenge Instructions

Your mission is to create a 3d flag like the flag in the video [here](./palestin.mov) without using any external assets . 




1. **3d flag**: implement the flag demonstrated in the video using 3d library and shaders  without using any external assets 

2. **Animation**: Apply suitable animation to the flag to make it visually appealing.



## Evaluation Criteria
Your challenge solution will be evaluated based on the following criteria:


- **Accuracy**: The accuracy of your 3d flag in replicating the flag from the reference video.

- **Parformance**: The accuracy of your 3d flag and the animation must be smooth and fast  (60 fps).

- **Styling**: The visual presentation and styling of the flag.

- **Code Quality**: The organization, readability, and adherence to best practices in your code.



## Note : Provide a video of your solution in action.


Best of luck, and free palestine !